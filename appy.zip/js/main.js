 var firstName = "Kevin";  // first name is a word
 var lastName = "Apoera";
 var age = 16// age is a number
//  let fullName = firstName + lastName;
let fullName = `${firstName} ${lastName}`;
 console.log(fullName);

 const boilingWaterTemperature = 100;

 let areYouHappy = true;

 let myPhone = {color:"black",makeACall:null}   


 if(age >=18) {console.log("welcome to KP Photography")}
 else{console.log("this page is not avalaible")}

 